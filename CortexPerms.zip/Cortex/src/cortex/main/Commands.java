package cortex.main;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import net.minecraft.server.v1_8_R3.CommandExecute;

public class Commands extends CommandExecute implements Listener, CommandExecutor {
	
	FileHandler FileHandler = new FileHandler();
	RankHandler RankHandler = new RankHandler();
	PlayerHandler PlayerHandler = new PlayerHandler();
	EvHandler EvHandler = new EvHandler();
	
	String setrank = "setrank";
	@EventHandler
	public void onCommand(PlayerCommandPreprocessEvent e) {
		Player p = e.getPlayer();
		String[] args = e.getMessage().split(" ");
		String cmd = args[0].replaceAll("/", "").toLowerCase();
		int rank = RankHandler.getRank(p);
		if(cmd.equals("setrank")){
			if(rank >= RankHandler.Admin) {
				e.setCancelled(true);
				if(args.length == 3);
				String targetname = args[1];
				@SuppressWarnings("deprecation")
				Player target = Bukkit.getPlayer(targetname);
				if(target != null) {
					int rankValue = 0;
					String rankName = args[2].toLowerCase();
					if(rankName.equals("owner")) {
						rankValue = RankHandler.Owner;
					}else if(rankName.equals("admin")) {
						rankValue = RankHandler.Admin;
					}else if(rankName.equals("mod")) {
						rankValue = RankHandler.Mod;
					}else if(rankName.equals("none")) {
						rankValue = RankHandler.None;
					}else {
						rankValue = -1;
					}
					if(rankValue >= 0) {
						if(rankValue < rank){
							if(RankHandler.getRank(target) < rank){
								p.sendMessage("Rank Has Been Set");
								if(RankHandler.setRank(target, rankValue));
								RankHandler.refreashRanks();
							}else{
								p.sendMessage("Cortex: Error Code 7");
							}
						}else {
							p.sendMessage("Cortex: Error Code 8");
						}
					}else {
						p.sendMessage("Cortex: Error Code 9");
					}
				}else {
					p.sendMessage("Cortex: Error Code 10 : <" + targetname + "> Can Not Be Found>");
				}
			}else {
				p.sendMessage("Cortex: Error Code 11: Did you mean: /setrank <Player> <Rank>");
			}
		}
	}
	
	String fly = "fly";
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			if(cmd.getName().equalsIgnoreCase(fly)) {
				Player p = (Player)sender;
				if(p.isFlying()) {
					p.setFlying(false);
				}else if (!p.isFlying()) {
					p.setFlying(true);
				}else {
					p.setFlying(false);
				}
			}
		}else {
			sender.sendMessage("Cortex: Error Code 1");
			return true;
		}
		return false;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
